import styled from "styled-components";
export const LoginForm = styled.div`
  width: 50%;
  border-radius: 20px;
  margin: auto;
  padding: 10px;
  text-align: center;
  border: 1px solid black;
  background-color: rgb(220, 220, 220);
`;
